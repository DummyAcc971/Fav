namespace GuestAPI.Models
{
    public class StockDataPoint
    {
        public string? Datetime { get; set; }
        public double Price { get; set; }
    }
}
